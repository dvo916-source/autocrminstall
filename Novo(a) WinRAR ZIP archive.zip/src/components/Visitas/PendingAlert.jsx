import React, { memo, useState } from 'react';
import { Phone, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const PendingAlert = memo(({ overdueCount, todayCount, performanceMode }) => {
    const [isVisible, setIsVisible] = useState(true);

    if ((overdueCount === 0 && todayCount === 0) || !isVisible) return null;

    const isOverdue = overdueCount > 0;

    return (
        <AnimatePresence>
            {isVisible && (
                <motion.div
                    {...(performanceMode ? {} : {
                        initial: { height: 0, opacity: 0 },
                        animate: { height: 'auto', opacity: 1 },
                        exit: { height: 0, opacity: 0, marginTop: 0, marginBottom: 0 }
                    })}
                    className={`mt-2 mb-2 p-4 border rounded-2xl flex items-center justify-between overflow-hidden relative shadow-2xl ${isOverdue ? 'bg-red-950/40 border-red-500/50' : 'bg-amber-950/40 border-amber-500/50'}`}
                >
                    <div className="flex items-center gap-5">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-inner ${isOverdue ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-amber-500/20 text-amber-400 border-amber-500/30'}`}>
                            <Phone className={performanceMode ? "" : "animate-bounce"} size={22} />
                        </div>
                        <div className="flex flex-col justify-center">
                            <h4 className="text-white font-black text-sm md:text-base tracking-tight uppercase leading-none mb-1">
                                {isOverdue ? 'Pendências Vencidas' : 'Pendências para Hoje'}
                            </h4>
                            <p className={`text-[10px] md:text-xs font-bold uppercase tracking-widest leading-none ${isOverdue ? 'text-red-400' : 'text-amber-400'}`}>
                                {isOverdue
                                    ? `${overdueCount} clientes aguardando retorno urgente`
                                    : `${todayCount} clientes para retornar hoje`}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        {isOverdue && (
                            <div className={`hidden sm:block bg-red-600 text-white text-[11px] font-black px-4 py-1.5 rounded-lg tracking-widest shadow-[0_0_15px_rgba(220,38,38,0.4)] ${performanceMode ? "" : "animate-pulse"}`}>
                                URGENTE
                            </div>
                        )}
                        <button
                            onClick={() => setIsVisible(false)}
                            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all border group ${isOverdue ? 'bg-red-500/10 hover:bg-red-500/30 text-red-300 border-red-500/20' : 'bg-amber-500/10 hover:bg-amber-500/30 text-amber-300 border-amber-500/20'}`}
                            title="Ocultar aviso"
                        >
                            <X size={18} className="group-hover:scale-110 transition-transform" />
                        </button>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
});

export default PendingAlert;
