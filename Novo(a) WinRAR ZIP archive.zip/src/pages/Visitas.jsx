﻿import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Users, Calendar, Filter, Plus, Search,
    TrendingUp, AlertCircle, Clock, X, ChevronDown
} from 'lucide-react';
import { useLoja } from '../context/LojaContext';
import { useUI } from '../context/UIContext';
import { useLeads } from '../context/LeadsContext';
import NewVisitModal from '../components/NewVisitModal';
import AgendaTimeline from '../components/Visitas/AgendaTimeline';

const Visitas = () => {
    const { currentLoja } = useLoja();
    const { performanceMode } = useUI();
    const { rawLeads, slaRisks, estoque, loading: contextLoading } = useLeads();

    const [isModalOpen, setIsModalOpen] = useState(false);

    // 🔥 ESTADOS DE FILTRO (FASE 4)
    const [filters, setFilters] = useState({
        vendedor: 'ALL',
        temperatura: 'ALL',
        onlySlaRisk: false
    });

    // 🧠 CÁLCULOS DE ELITE (DYNAMICS METRICS)
    const stats = useMemo(() => {
        if (!rawLeads) return { attendance: '0%', open: 0, ticket: 'R$ 0', alerts: 0 };

        const scheduledLeads = rawLeads.filter(l => l.data_agendamento || l.status_pipeline === 'Agendado');
        const visited = scheduledLeads.filter(l => l.visitou_loja === 1).length;
        const totalPast = scheduledLeads.filter(l => l.visitou_loja === 1 || l.nao_compareceu === 1).length;

        const attendanceRate = totalPast > 0 ? ((visited / totalPast) * 100).toFixed(1) : '0';
        const openVisits = scheduledLeads.filter(l => !l.visitou_loja && !l.nao_compareceu).length;

        // Ticket Médio (Cruzando com estoque ou usando valor_proposta)
        let totalValue = 0;
        let countWithPrice = 0;
        scheduledLeads.forEach(l => {
            const cleanInteresse = (l.veiculo_interesse || '').split(' #')[0].trim().toLowerCase();
            const car = (estoque || []).find(c => (c.nome || '').toLowerCase().includes(cleanInteresse));
            const price = car?.valor ? parseFloat(car.valor.replace(/\D/g, '')) / 100 : (l.valor_proposta || 0);
            if (price > 0) {
                totalValue += price;
                countWithPrice++;
            }
        });
        const avgTicket = countWithPrice > 0 ? (totalValue / countWithPrice) : 0;

        return {
            attendance: `${attendanceRate}%`,
            open: openVisits,
            ticket: avgTicket.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }),
            alerts: slaRisks?.length || 0
        };
    }, [rawLeads, slaRisks, estoque]);

    // Extrair lista de vendedores únicos
    const vendedores = useMemo(() => {
        if (!rawLeads) return [];
        const set = new Set();
        rawLeads.forEach(l => {
            const v = l.vendedor_sdr || l.vendedor;
            if (v) set.add(v);
        });
        return Array.from(set).sort();
    }, [rawLeads]);

    const resetFilters = () => setFilters({ vendedor: 'ALL', temperatura: 'ALL', onlySlaRisk: false });

    return (
        <div className="flex flex-col h-full bg-[#0f172a] overflow-hidden relative">
            {/* 🌌 BACKGROUND OVERLAYS */}
            {!performanceMode && (
                <>
                    <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-cyan-500/10 blur-[150px] rounded-full pointer-events-none animate-pulse" />
                    <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/5 blur-[150px] rounded-full pointer-events-none" />
                </>
            )}

            {/* ── HEADER PREMIUM (AERO GLASS) ─────────────────────── */}
            <header className="px-8 pt-10 pb-8 shrink-0 relative overflow-hidden backdrop-blur-md bg-white/[0.01] border-b border-white/5 z-20">
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 relative z-10">
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                    >
                        <div className="flex items-center gap-4 mb-3">
                            <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center shadow-2xl relative overflow-hidden group">
                                <Users size={24} className="text-cyan-400 group-hover:scale-110 transition-transform" />
                            </div>
                            <h1 className="text-4xl font-black text-white tracking-tighter italic uppercase leading-none">
                                CONTROLE DE <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">AGENDAMENTOS</span>
                            </h1>
                        </div>
                        <div className="flex items-center gap-3 pl-1">
                            <div className="w-8 h-[2px] bg-cyan-500/40 rounded-full" />
                            <p className="text-slate-500 font-black text-[9px] uppercase tracking-[0.4em]">
                                Gestão Cronológica Padrão Ouro • {currentLoja?.nome || 'VexCORE Cloud'}
                            </p>
                        </div>
                    </motion.div>

                    {/* 🔥 FILTROS CIRÚRGICOS (FASE 4) */}
                    <div className="flex flex-wrap items-center gap-3">
                        {/* Vendedor Filter */}
                        <div className="relative group">
                            <select
                                value={filters.vendedor}
                                onChange={(e) => setFilters(prev => ({ ...prev, vendedor: e.target.value }))}
                                className="appearance-none bg-black/40 border border-white/5 text-slate-300 text-[10px] font-black uppercase tracking-widest pl-10 pr-10 py-3.5 rounded-2xl outline-none focus:border-cyan-500/30 transition-all cursor-pointer hover:bg-black/60"
                            >
                                <option value="ALL">TODOS VENDEDORES</option>
                                {vendedores.map(v => <option key={v} value={v}>{v.toUpperCase()}</option>)}
                            </select>
                            <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-500/50" size={14} />
                            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 pointer-events-none" size={12} />
                        </div>

                        {/* Temperatura Filter */}
                        <div className="flex p-1 bg-black/40 rounded-2xl border border-white/5 transition-all">
                            {['ALL', 'Quente', 'Morno', 'Frio'].map(t => (
                                <button
                                    key={t}
                                    onClick={() => setFilters(prev => ({ ...prev, temperatura: t }))}
                                    className={`px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${filters.temperatura === t
                                            ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20'
                                            : 'text-slate-500 hover:text-white hover:bg-white/5'
                                        }`}
                                >
                                    {t === 'ALL' ? 'TEMPERATURA' : t}
                                </button>
                            ))}
                        </div>

                        {/* Reset Filter Button */}
                        {(filters.vendedor !== 'ALL' || filters.temperatura !== 'ALL' || filters.onlySlaRisk) && (
                            <motion.button
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                onClick={resetFilters}
                                className="w-11 h-11 flex items-center justify-center bg-white/5 border border-white/10 text-red-400 rounded-2xl hover:bg-red-500/20 transition-all shadow-xl"
                                title="Limpar Filtros"
                            >
                                <X size={18} strokeWidth={3} />
                            </motion.button>
                        )}

                        <motion.button
                            whileHover={{ scale: 1.02, y: -2 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setIsModalOpen(true)}
                            className="bg-cyan-500 hover:bg-cyan-400 text-black px-8 py-4 rounded-2xl font-black text-[11px] tracking-[0.2em] flex items-center gap-3 transition-all shadow-[0_10px_30px_rgba(6,182,212,0.3)] ml-2"
                        >
                            <Plus size={16} strokeWidth={4} />
                            NOVO AGENDAMENTO
                        </motion.button>
                    </div>
                </div>
            </header>

            {/* ── MAIN CONTENT (WIDESCREEN) ────────────────────────── */}
            <main className="flex-1 min-h-0 p-8 pt-8 flex flex-col md:flex-row gap-8 overflow-hidden relative z-10">
                {/* 🧭 TIMELINE CENTRAL */}
                <div className="flex-[3] flex flex-col bg-white/[0.02] border border-white/5 rounded-[3.5rem] p-10 overflow-hidden relative group backdrop-blur-2xl shadow-2xl">
                    <div className="flex items-center justify-between mb-10 shrink-0">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-cyan-500/10 rounded-2xl border border-cyan-500/20">
                                <Calendar size={20} className="text-cyan-500" />
                            </div>
                            <div>
                                <h2 className="text-sm font-black text-white uppercase tracking-[0.2em] italic">Linha do Tempo</h2>
                                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mt-1">Status de Ocupação da Central</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            {filters.onlySlaRisk && (
                                <div className="px-3 py-1 bg-red-500/20 border border-red-500/30 rounded-lg text-[9px] font-black text-red-400 uppercase tracking-widest animate-pulse">
                                    Filtro: Alertas Ativo
                                </div>
                            )}
                        </div>
                    </div>

                    <AgendaTimeline filters={filters} />
                </div>

                {/* 📊 PAINEL DE INTELIGÊNCIA */}
                <aside className="w-full md:w-[380px] flex flex-col gap-6 overflow-y-auto no-scrollbar shrink-0">
                    <div className="p-8 bg-gradient-to-br from-[#1e293b] to-[#0f172a] border border-white/10 rounded-[3rem] shadow-2xl relative overflow-hidden group">
                        {!performanceMode && (
                            <div className="absolute inset-0 bg-cyan-500/[0.02] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                        )}
                        <div className="flex items-center gap-4 mb-8">
                            <div className="p-3 bg-emerald-500/10 rounded-2xl">
                                <TrendingUp size={18} className="text-emerald-400" />
                            </div>
                            <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Célula de Performance</h3>
                        </div>
                        <div className="space-y-5">
                            {[
                                { label: 'Taxa de Comparecimento', value: stats.attendance, color: 'cyan', tendency: '+2.4%' },
                                { label: 'Visitas em Aberto', value: stats.open, color: 'amber', tendency: '' },
                                { label: 'Ticket Médio', value: stats.ticket, color: 'emerald', tendency: '' },
                            ].map(stat => (
                                <div key={stat.label} className="bg-black/30 p-5 rounded-[2rem] border border-white/5 hover:border-white/10 transition-all">
                                    <div className="flex justify-between items-start mb-2">
                                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{stat.label}</p>
                                        {stat.tendency && <span className="text-[8px] font-black text-emerald-400">{stat.tendency}</span>}
                                    </div>
                                    <p className="text-2xl font-black text-white italic tracking-tighter tabular-nums">{stat.value}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* 🔥 ALERTA DINÂMICO CLICÁVEL (FASE 4) */}
                    <div
                        onClick={() => setFilters(prev => ({ ...prev, onlySlaRisk: !prev.onlySlaRisk }))}
                        className={`p-8 border rounded-[3rem] flex items-start gap-5 relative overflow-hidden transition-all duration-500 cursor-pointer 
                            ${filters.onlySlaRisk
                                ? 'bg-red-500/20 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.2)]'
                                : 'bg-red-500/5 border-red-500/10 hover:bg-red-500/10'}`}
                    >
                        <div className="p-3 bg-red-500/10 rounded-2xl shrink-0">
                            <AlertCircle size={20} className="text-red-400" />
                        </div>
                        <div>
                            <p className="text-xs font-black text-red-100 uppercase tracking-widest mb-2 italic">Ação Necessária</p>
                            <p className="text-[10px] font-bold text-slate-400 leading-relaxed uppercase tracking-tight">
                                <span className="text-red-400">{stats.alerts} Clientes</span> detectados em atraso crítico. Clique para filtrar.
                            </p>
                        </div>
                        {filters.onlySlaRisk && (
                            <div className="absolute bottom-4 right-6">
                                <span className="text-[8px] font-black text-red-500 uppercase animate-pulse">ATIVADO</span>
                            </div>
                        )}
                    </div>

                    <div className="mt-auto p-10 bg-white/[0.01] border border-dashed border-white/5 rounded-[3rem] text-center">
                        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                            <TrendingUp size={24} className="text-slate-800" />
                        </div>
                        <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] leading-relaxed">
                            Módulo de IA <br />em Calibração
                        </p>
                    </div>
                </aside>
            </main>

            <NewVisitModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSuccess={() => setIsModalOpen(false)}
            />
        </div>
    );
};

export default Visitas;
