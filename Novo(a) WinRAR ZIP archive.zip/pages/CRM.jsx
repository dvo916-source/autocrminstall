import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Search, Filter, Plus, FileText, Database,
    LayoutGrid, List as ListIcon, Calendar as CalendarIcon,
    Check, ChevronDown, GripVertical, Clock, Users, Zap, X, AlertTriangle, Target, Car
} from 'lucide-react';
import {
    DndContext, closestCorners, KeyboardSensor, PointerSensor,
    useSensor, useSensors, DragOverlay, defaultDropAnimationSideEffects,
    useDroppable
} from '@dnd-kit/core';
import { SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import { useUI } from '../context/UIContext';
import { useLoja } from '../context/LojaContext';
import { useLeads } from '../context/LeadsContext';
import NewVisitModal from '../components/NewVisitModal';
import ReportModal from '../components/ReportModal';
import VisitListItem from '../components/Visitas/VisitListItem';
import PendingAlert from '../components/Visitas/PendingAlert';

const PIPELINE_STATUSES = [
    { id: 'Novos Leads', label: 'Novos Leads', color: 'border-cyan-500/50', glow: 'shadow-cyan-500/40', bg: 'bg-cyan-500' },
    { id: 'Primeiro Contato', label: 'Primeiro Contato', color: 'border-blue-500/50', glow: 'shadow-blue-500/40', bg: 'bg-blue-500' },
    { id: 'Em Negociação', label: 'Em Negociação', color: 'border-amber-500/50', glow: 'shadow-amber-500/40', bg: 'bg-amber-500' },
    { id: 'Agendado', label: 'Agendado', color: 'border-orange-500/50', glow: 'shadow-orange-500/40', bg: 'bg-orange-500' },
    { id: 'Recontato', label: 'Recontato', color: 'border-purple-500/50', glow: 'shadow-purple-500/40', bg: 'bg-purple-500' },
    { id: 'Ganho', label: 'Ganho', color: 'border-green-500/50', glow: 'shadow-green-500/40', bg: 'bg-green-500' },
    { id: 'Perdido', label: 'Perdido', color: 'border-red-500/50', glow: 'shadow-red-500/40', bg: 'bg-red-500' },
    { id: 'Cancelado', label: 'Cancelado', color: 'border-gray-500/50', glow: 'shadow-gray-500/40', bg: 'bg-gray-500' }
];

export default function CRM({ user }) {
    const { performanceMode } = useUI();
    const { currentLoja } = useLoja();
    const { filteredLeads, estoque, overdueRecontacts, dueTodayRecontacts, periodFilter, setPeriodFilter, refreshData } = useLeads();

    const [usuarios, setUsuarios] = useState([]);
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const { ipcRenderer } = window.require('electron');
                const res = await ipcRenderer.invoke('get-list-users', currentLoja?.id);
                setUsuarios(res || []);
            } catch (e) { }
        };
        if (currentLoja?.id) fetchUsers();
    }, [currentLoja?.id]);

    const [viewMode, setViewMode] = useState('kanban');
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState('TODOS');

    const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [isStatusMenuOpen, setIsStatusMenuOpen] = useState(false);
    const filterRef = useRef(null);
    const statusRef = useRef(null);

    const [isVisitModalOpen, setIsVisitModalOpen] = useState(false);
    const [isReportOpen, setIsReportOpen] = useState(false);
    const [editingLead, setEditingLead] = useState(null);

    useEffect(() => {
        if (viewMode === 'kanban') setActiveTab('TODOS');
    }, [viewMode]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (filterRef.current && !filterRef.current.contains(event.target)) setIsFilterOpen(false);
            if (statusRef.current && !statusRef.current.contains(event.target)) setIsStatusMenuOpen(false);
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const availableMonths = useMemo(() => {
        const monthsMap = new Map();
        const now = new Date();
        const startDate = new Date(2026, 0, 1);
        let tempDate = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
        const futureLimit = new Date(now.getFullYear(), now.getMonth() - 1, 1);

        while (tempDate <= futureLimit) {
            const id = `${tempDate.getFullYear()}-${String(tempDate.getMonth() + 1).padStart(2, '0')}`;
            monthsMap.set(id, tempDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }));
            tempDate.setMonth(tempDate.getMonth() + 1);
        }
        return Array.from(monthsMap.entries()).map(([id, label]) => ({ id, label })).sort((a, b) => b.id.localeCompare(a.id));
    }, []);

    const togglePeriodFilter = (id) => {
        setPeriodFilter(prev => {
            if (id === 'all') return ['all'];
            let next = prev.filter(p => p !== 'all');
            if (next.includes(id)) {
                const filtered = next.filter(p => p !== id);
                return filtered.length === 0 ? ['current_month'] : filtered;
            }
            return [...next, id];
        });
        setIsFilterOpen(false);
    };

    const displayLeads = useMemo(() => {
        return filteredLeads.filter(lead => {
            if (viewMode === 'list' && activeTab !== 'TODOS') {
                if ((lead.status_pipeline || '').toLowerCase() !== activeTab.toLowerCase()) return false;
            }
            if (searchTerm) {
                const term = searchTerm.toLowerCase();
                const textToSearch = `${lead.cliente || ''} ${lead.veiculo_interesse || ''} ${lead.telefone || ''} ${lead.placa || ''}`.toLowerCase();
                if (!textToSearch.includes(term)) return false;
            }
            return true;
        });
    }, [filteredLeads, activeTab, searchTerm, viewMode]);

    const tabCounts = useMemo(() => {
        const counts = { TODOS: filteredLeads.length };
        filteredLeads.forEach(v => {
            const s = v.status_pipeline || '';
            counts[s] = (counts[s] || 0) + 1;
        });
        return counts;
    }, [filteredLeads]);

    const [activeId, setActiveId] = useState(null);
    const sensors = useSensors(
        useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
        useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
    );

    const handleUpdateLeadStatus = async (leadId, newStatus) => {
        try {
            const { ipcRenderer } = window.require('electron');
            await ipcRenderer.invoke('update-visita-status', { id: leadId, status: newStatus, pipeline: newStatus });
            refreshData();
        } catch (err) { console.error("Erro ao mover lead:", err); }
    };

    const handleDragStart = (event) => setActiveId(event.active.id);

    const handleDragEnd = async (event) => {
        const { active, over } = event;
        setActiveId(null);
        if (!over) return;

        const leadId = active.id;
        const overId = over.id;

        let targetStatus = PIPELINE_STATUSES.find(c => c.id === overId)?.id;
        if (!targetStatus) {
            const overLead = filteredLeads.find(l => l.id === overId);
            if (overLead) targetStatus = overLead.status_pipeline;
        }

        const currentLead = filteredLeads.find(l => l.id === leadId);

        if (targetStatus && currentLead && currentLead.status_pipeline !== targetStatus) {
            await handleUpdateLeadStatus(leadId, targetStatus);
        }
    };

    return (
        // 🔥 MAGICA 1: Ancoragem total na tela (`absolute inset-0`)
        <div className="absolute inset-0 flex flex-col overflow-hidden bg-[#0f172a] z-0">

            <div className="px-6 lg:px-8 py-5 border-b border-white/[0.05] z-50 relative bg-[#0a101d] shrink-0">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">

                    <div className="flex items-center gap-6 shrink-0">
                        <div className="flex items-center gap-3">
                            <div className="w-1.5 h-8 bg-cyan-500 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.5)]" />
                            <h1 className="text-2xl font-black text-white italic tracking-tighter uppercase flex items-center gap-2">
                                Leads <Zap size={20} className="text-cyan-500/50 hidden sm:block" />
                            </h1>
                        </div>

                        <div className="flex bg-[#111827] p-1 rounded-xl border border-white/10 shadow-inner">
                            <button onClick={() => setViewMode('kanban')} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all ${viewMode === 'kanban' ? 'bg-cyan-500 text-black shadow-md' : 'text-slate-400 hover:text-white'}`}>
                                <LayoutGrid size={14} /> Kanban
                            </button>
                            <button onClick={() => setViewMode('list')} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all ${viewMode === 'list' ? 'bg-cyan-500 text-black shadow-md' : 'text-slate-400 hover:text-white'}`}>
                                <ListIcon size={14} /> Lista
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 w-full max-w-lg relative group/search mx-auto lg:mx-0">
                        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within/search:text-cyan-400 transition-colors" />
                        <input
                            type="text"
                            placeholder="Buscar lead, telefone, veículo..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-[#111827] border border-white/[0.07] rounded-xl pl-11 pr-10 py-3 text-sm text-white outline-none focus:border-cyan-500/50 transition-all shadow-inner"
                        />
                        {searchTerm && (
                            <button onClick={() => setSearchTerm('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
                                <X size={16} />
                            </button>
                        )}
                    </div>

                    <div className="flex items-center justify-end gap-3 shrink-0 overflow-visible pb-1 lg:pb-0">
                        <AnimatePresence>
                            {viewMode === 'list' && (
                                <motion.div initial={{ opacity: 0, width: 0 }} animate={{ opacity: 1, width: 'auto' }} exit={{ opacity: 0, width: 0 }} className="flex items-center gap-3 overflow-visible">
                                    <div className="relative" ref={statusRef}>
                                        <button onClick={() => setIsStatusMenuOpen(!isStatusMenuOpen)} className="flex items-center gap-2 bg-[#111827] px-4 py-3 rounded-xl border border-white/[0.07] hover:border-cyan-500/30 text-slate-300 hover:text-white transition-all whitespace-nowrap">
                                            <Filter size={14} className="text-cyan-400" />
                                            <span className="text-[11px] font-bold uppercase tracking-wider">
                                                Status: <span className="text-white ml-1">{activeTab}</span>
                                            </span>
                                            <ChevronDown size={14} className={`text-slate-500 transition-transform ${isStatusMenuOpen ? 'rotate-180' : ''}`} />
                                        </button>
                                        <AnimatePresence>
                                            {isStatusMenuOpen && (
                                                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} className="absolute top-[calc(100%+8px)] right-0 w-[240px] bg-[#0b101e] border border-white/15 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.9)] z-[1000] overflow-hidden p-2">
                                                    <div className="max-h-[300px] overflow-y-auto custom-scrollbar space-y-1">
                                                        {['TODOS', ...PIPELINE_STATUSES.map(s => s.id)].map(tab => {
                                                            const count = tabCounts[tab] || 0;
                                                            const isSel = activeTab === tab;
                                                            return (
                                                                <button key={tab} onClick={() => { setActiveTab(tab); setIsStatusMenuOpen(false); }} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${isSel ? 'bg-cyan-500 text-black' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
                                                                    <div className="flex items-center gap-2">
                                                                        {tab}
                                                                        {isSel && <Check size={14} />}
                                                                    </div>
                                                                    <span className={`px-2 py-0.5 rounded-md leading-none tabular-nums ${isSel ? 'bg-black/20 text-black' : 'bg-white/5 text-slate-500'}`}>{count}</span>
                                                                </button>
                                                            );
                                                        })}
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>
                                    </div>
                                    <div className="relative hidden sm:block" ref={filterRef}>
                                        <button onClick={() => setIsFilterOpen(!isFilterOpen)} className="flex items-center gap-2 bg-[#111827] px-4 py-3 rounded-xl border border-white/[0.07] hover:border-cyan-500/30 text-slate-300 hover:text-white transition-all whitespace-nowrap">
                                            <CalendarIcon size={14} className="text-cyan-400" />
                                            <span className="text-[11px] font-bold uppercase tracking-wider">
                                                {periodFilter.includes('all') ? 'Vida Toda' : periodFilter.length === 1 && periodFilter[0] === 'current_month' ? 'Mês Atual' : 'Período'}
                                            </span>
                                            <ChevronDown size={14} className={`text-slate-500 transition-transform ${isFilterOpen ? 'rotate-180' : ''}`} />
                                        </button>
                                        <AnimatePresence>
                                            {isFilterOpen && (
                                                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} className="absolute top-[calc(100%+8px)] right-0 w-[220px] bg-[#0b101e] border border-white/15 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.9)] z-[1000] overflow-hidden p-2">
                                                    <div className="max-h-[280px] overflow-y-auto custom-scrollbar space-y-1">
                                                        <button onClick={() => togglePeriodFilter('current_month')} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${periodFilter.includes('current_month') ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
                                                            Mês Atual {periodFilter.includes('current_month') && <Check size={14} />}
                                                        </button>
                                                        <div className="h-px bg-white/5 my-2" />
                                                        {availableMonths.map(m => {
                                                            const isSel = periodFilter.includes(m.id);
                                                            return (
                                                                <button key={m.id} onClick={() => togglePeriodFilter(m.id)} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${isSel ? 'bg-purple-600 text-white' : 'text-slate-500 hover:bg-white/5 hover:text-white'}`}>
                                                                    {m.label} {isSel && <Check size={14} />}
                                                                </button>
                                                            );
                                                        })}
                                                        <div className="h-px bg-white/5 my-2" />
                                                        <button onClick={() => togglePeriodFilter('all')} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all italic ${periodFilter.includes('all') ? 'bg-amber-500 text-white' : 'text-slate-500 hover:bg-white/5 hover:text-white'}`}>
                                                            Vida Toda {periodFilter.includes('all') && <Check size={14} />}
                                                        </button>
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>
                                    </div>
                                    <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={() => setIsReportOpen(true)} className="hidden md:flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.07] text-slate-300 hover:text-white transition-all text-[11px] font-bold uppercase tracking-wider whitespace-nowrap">
                                        <FileText size={16} className="text-amber-400" /> PDF
                                    </motion.button>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={() => { setEditingLead(null); setIsVisitModalOpen(true); }} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white transition-all text-xs font-black uppercase tracking-widest shadow-lg shadow-cyan-900/20 whitespace-nowrap">
                            <Plus size={16} /> Novo Lead
                        </motion.button>
                    </div>
                </div>

                {(overdueRecontacts.length > 0 || dueTodayRecontacts.length > 0) && (
                    <div className="px-6 lg:px-8 pt-4 shrink-0">
                        <PendingAlert overdueCount={overdueRecontacts.length} todayCount={dueTodayRecontacts.length} performanceMode={performanceMode} />
                    </div>
                )}

                {/* 🔥 MÁGICA 2: O Container de Conteúdo Ancorado */}
                <div className="flex-1 min-h-0 relative w-full bg-[#0d1526] mt-4">
                    <AnimatePresence mode="wait">

                        {viewMode === 'kanban' && (
                            <motion.div key="kanban" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }}
                                className="absolute inset-0 flex items-stretch overflow-x-auto overflow-y-hidden gap-4 md:gap-6 pb-6 px-6 lg:px-8">
                                <DndContext sensors={sensors} collisionDetection={closestCorners} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
                                    {PIPELINE_STATUSES.map(col => {
                                        const colLeads = displayLeads.filter(l => (l.status_pipeline || '').toLowerCase() === col.id.toLowerCase());
                                        return (
                                            <KanbanColumn key={col.id} col={col} leads={colLeads}>
                                                {colLeads.map(lead => (
                                                    <KanbanCard key={lead.id} lead={lead} estoque={estoque} usuarios={usuarios} onClick={() => { setEditingLead(lead); setIsVisitModalOpen(true); }} />
                                                ))}
                                            </KanbanColumn>
                                        );
                                    })}
                                    <DragOverlay dropAnimation={{ sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.4' } } }) }}>
                                        {activeId ? <KanbanCard lead={displayLeads.find(l => l.id === activeId)} estoque={estoque} usuarios={usuarios} isDragging /> : null}
                                    </DragOverlay>
                                </DndContext>
                            </motion.div>
                        )}

                        {viewMode === 'list' && (
                            <motion.div key="list" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                                className="absolute inset-0 overflow-y-auto custom-scrollbar w-full pb-10">
                                <div className="px-6 lg:px-8 space-y-4 max-w-[1800px] mx-auto">
                                    {displayLeads.length > 0 ? (
                                        displayLeads.map((v, index) => {
                                            const isClosed = ['ganho', 'perdido', 'cancelado'].includes((v.status_pipeline || '').toLowerCase());
                                            return (
                                                <VisitListItem
                                                    key={v.id || index}
                                                    v={v}
                                                    index={index}
                                                    status={v.status_pipeline}
                                                    isClosed={isClosed}
                                                    dateStr={v.data_agendamento ? new Date(v.data_agendamento).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) : '—'}
                                                    timeStr={v.data_agendamento ? new Date(v.data_agendamento).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                                                    setSelectedVisit={() => { setEditingLead(v); setIsVisitModalOpen(true); }}
                                                    formatCurrency={(val) => `R$ ${val || '0,00'}`}
                                                    getCleanVehicleName={(name) => name}
                                                    usuarios={usuarios}
                                                    estoque={estoque}
                                                    loadData={refreshData}
                                                    performanceMode={performanceMode}
                                                />
                                            );
                                        })
                                    ) : (
                                        <div className="flex flex-col items-center justify-center gap-4 h-full min-h-[300px] opacity-40">
                                            <div className="w-16 h-16 rounded-full bg-cyan-500/10 flex items-center justify-center border border-cyan-500/15">
                                                <Target size={28} className="text-cyan-400" />
                                            </div>
                                            <div className="text-center">
                                                <h3 className="text-sm font-semibold text-white mb-1">Nenhum lead encontrado</h3>
                                                <p className="text-[11px] text-slate-500 uppercase tracking-widest">Altere os filtros ou adicione um novo lead</p>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>

            <ReportModal isOpen={isReportOpen} onClose={() => setIsReportOpen(false)} visitas={filteredLeads} availableMonths={availableMonths} lojaName={currentLoja?.nome || 'IRW Motors'} />
            <NewVisitModal isOpen={isVisitModalOpen} editingTask={editingLead} onClose={() => { setIsVisitModalOpen(false); setEditingLead(null); }} onSuccess={refreshData} />
        </div>
    );
}

function KanbanColumn({ col, leads, children }) {
    const { setNodeRef } = useDroppable({ id: col.id, data: { type: 'Column', col } });
    return (
        <div className="w-[85vw] sm:w-[350px] shrink-0 h-full flex flex-col group/col">
            <div className={`flex items-center justify-between mb-4 pb-3 border-b-2 ${col.color} shrink-0`}>
                <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${col.bg} ${col.glow} animate-pulse`} />
                    <h3 className="text-[13px] font-black text-white uppercase tracking-widest">{col.label}</h3>
                </div>
                <div className="bg-white/5 px-3 py-1 rounded-full text-[11px] font-black tabular-nums">{leads.length}</div>
            </div>

            {/* 🔥 MÁGICA 3: O Scroll Perfeito Vertical nas colunas */}
            <div className="flex-1 min-h-0 relative">
                <SortableContext id={col.id} items={leads.map(l => l.id)} strategy={verticalListSortingStrategy}>
                    <div ref={setNodeRef} className="absolute inset-0 overflow-y-auto custom-scrollbar pb-10 space-y-3 pr-2">
                        {children}
                        {leads.length === 0 && (
                            <div className="h-20 border border-dashed border-white/10 rounded-xl flex items-center justify-center opacity-30 text-[10px] font-bold uppercase tracking-widest">Solte o Lead Aqui</div>
                        )}
                    </div>
                </SortableContext>
            </div>
        </div>
    );
}

const KanbanCard = ({ lead, isDragging, onClick, estoque, usuarios }) => {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging: isSorting } = useSortable({
        id: lead.id, data: { type: 'Task', lead }
    });
    const style = { transform: CSS.Transform.toString(transform), transition, opacity: isSorting ? 0.3 : 1, zIndex: isSorting ? 10 : 1 };

    const isSlaRisk = lead.isSlaRisk;

    const getFirstName = (fullName) => {
        if (!fullName) return 'Indefinido';
        const first = fullName.trim().split(' ')[0];
        return first.charAt(0).toUpperCase() + first.slice(1).toLowerCase();
    };
    const getCleanNameFallback = (rawEmail) => {
        if (!rawEmail) return 'Indefinido';
        const namePart = rawEmail.split('@')[0].split('.')[0].replace(/[0-9]/g, '');
        return namePart.charAt(0).toUpperCase() + namePart.slice(1).toLowerCase();
    };

    const sdrObj = (usuarios || []).find(u => u.username?.toLowerCase() === (lead.vendedor_sdr || '').toLowerCase());
    const sdrName = sdrObj ? getFirstName(sdrObj.nome_completo || sdrObj.nome || sdrObj.username) : getCleanNameFallback(lead.vendedor_sdr);
    const sdrInitial = sdrName.charAt(0);

    const cleanInteresse = (lead.veiculo_interesse || '').split(' #')[0].trim();

    const targetCar = (estoque || []).find(car => {
        const carName = (car.nome || '').toLowerCase().trim();
        const searchName = cleanInteresse.toLowerCase();
        return carName === searchName || carName.includes(searchName) || searchName.includes(carName);
    });

    let photoUrl = null;
    if (targetCar) {
        try {
            const fotos = typeof targetCar.fotos === 'string' ? JSON.parse(targetCar.fotos) : targetCar.fotos;
            if (Array.isArray(fotos) && fotos.length > 0) photoUrl = fotos[0];
            else if (targetCar.foto) photoUrl = targetCar.foto;
        } catch (e) { photoUrl = targetCar.foto || null; }
    }
    const finalPrice = targetCar?.valor || lead.valor_proposta || 'Consulte';

    return (
        <div ref={setNodeRef} style={style} {...attributes} className={`relative ${isDragging ? 'z-50' : ''}`}>
            <div
                onClick={onClick}
                className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 border flex flex-col gap-3
                ${isDragging ? 'shadow-[0_20px_40px_rgba(0,0,0,0.8)] border-cyan-500 scale-105 bg-[#1e293b]' : 'shadow-lg bg-[#111827]'}
                ${isSlaRisk ? 'border-red-500 bg-red-950/40 shadow-[0_0_20px_rgba(239,68,68,0.2)]' : 'border-white/[0.08] hover:border-cyan-500/40 hover:bg-[#151e32]'}`}
            >
                {isSlaRisk && (
                    <div className="absolute -top-3 -right-3 bg-red-600 text-white text-[9px] font-black uppercase px-3 py-1.5 rounded-xl shadow-[0_0_15px_rgba(220,38,38,0.6)] border border-red-400 flex items-center gap-1.5 animate-pulse z-20">
                        <AlertTriangle size={12} /> Prazo Estourado
                    </div>
                )}

                <div className="flex gap-4">
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <div {...listeners} className="cursor-grab p-1 hover:bg-white/10 rounded-md -ml-1">
                                    <GripVertical size={14} className={isSlaRisk ? 'text-red-400' : 'text-slate-500'} />
                                </div>
                                <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded shadow-inner ${isSlaRisk ? 'bg-red-500/20 text-red-400' : 'bg-cyan-500/10 text-cyan-400'}`}>
                                    {lead.portal || 'Manual'}
                                </span>
                            </div>
                            <h4 className={`text-[15px] leading-tight font-black truncate pr-2 ${isSlaRisk ? 'text-red-100' : 'text-white'}`}>{lead.cliente}</h4>
                            <p className="text-xs text-slate-400 truncate mt-1">{cleanInteresse || 'Carro não definido'}</p>
                        </div>

                        <div className="flex items-center gap-3 mt-3">
                            <div className="flex items-center gap-1.5 bg-black/30 rounded-lg px-2 py-1 border border-white/5">
                                <div className="w-4 h-4 rounded-full bg-cyan-600 text-black flex items-center justify-center text-[8px] font-black">
                                    {sdrInitial}
                                </div>
                                <span className="text-[10px] font-bold text-slate-300">{sdrName}</span>
                            </div>
                            {!isSlaRisk && lead.temperatura === 'Quente' && <span className="text-[13px]" title="Lead Quente">🔥</span>}
                        </div>
                    </div>

                    <div className={`w-[100px] shrink-0 flex flex-col items-end justify-between gap-2 border-l border-white/5 pl-4 ${isSlaRisk ? 'pt-5' : ''}`}>
                        <div className="w-full aspect-[4/3] rounded-lg bg-black/40 border border-white/10 overflow-hidden relative shadow-inner">
                            {photoUrl ? (
                                <img src={photoUrl} alt="Veículo" className="w-full h-full object-cover opacity-90" />
                            ) : (
                                <div className="absolute inset-0 flex items-center justify-center text-slate-700">
                                    <Car size={20} strokeWidth={1.5} />
                                </div>
                            )}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                        </div>
                        <div className="text-right w-full">
                            <span className="block text-[8px] font-bold text-slate-500 uppercase tracking-widest leading-none mb-0.5">Valor</span>
                            <span className="block text-xs font-black text-green-400 whitespace-nowrap leading-none">
                                {finalPrice}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
